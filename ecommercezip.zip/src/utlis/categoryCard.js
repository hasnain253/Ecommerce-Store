import CategoryPhone from "../assets/images/Category-CellPhone.png";
import CategoryComputer from "../assets/images/Category-Computer.png";
import CategorySmartWatch from "../assets/images/Category-SmartWatch.png";
import CategoryCamera from "../assets/images/Category-Camera .png";
import CategoryHeadphone from "../assets/images/Category-Headphone.png";
import CategoryGaming from "../assets/images/Category-Gamepad.png";

export const categoryCard = [
  {
    id: 1,
    icon: CategoryPhone,
    title: "Phones",
    alt: "category-phone",
  },
  {
    id: 2,
    icon: CategoryComputer,
    title: "Computer",
    alt: "category-computer",
  },
  {
    id: 3,
    icon: CategorySmartWatch,
    title: "SmartWatch",
    alt: "category-smartwatch",
  },
  {
    id: 4,
    icon: CategoryCamera,
    title: "Camera",
    alt: "category-camera",
  },
  {
    id: 5,
    icon: CategoryHeadphone,
    title: "HeadPhone",
    alt: "category-headphone",
  },
  {
    id: 6,
    icon: CategoryGaming,
    title: "Gaming",
    alt: "category-gaming",
  },
  {
    id: 7,
    icon: CategoryComputer,
    title: "Computer",
    alt: "category-computer",
  },
  {
    id: 8,
    icon: CategorySmartWatch,
    title: "SmartWatch",
    alt: "category-smartwatch",
  },
  {
    id: 9,
    icon: CategoryCamera,
    title: "Camera",
    alt: "category-camera",
  },
  {
    id: 10,
    icon: CategoryHeadphone,
    title: "HeadPhone",
    alt: "category-headphone",
  },
  {
    id: 11,
    icon: CategoryGaming,
    title: "Gaming",
    alt: "category-gaming",
  },
];
