import TomCruise from "../assets/images/tomcruise.png";
import EmmaWatson from "../assets/images/emmawatson.png";
import WillSmith from "../assets/images/willsmith.png";

export const teamData = [
  {
    id: 1,
    image: TomCruise,
    name: "Tom Cruise",
    title: "Founder & Chairman",
  },
  {
    id: 2,
    image: EmmaWatson,
    name: "Emma Watson",
    title: "Managing Director",
  },
  {
    id: 3,
    image: WillSmith,
    name: "Will SMith",
    title: "Product Designer",
  },
  {
    id: 4,
    image: TomCruise,
    name: "Tom Cruise",
    title: "Founder & Chairman",
  },
  {
    id: 5,
    image: EmmaWatson,
    name: "Tom Cruise",
    title: "Founder & Chairman",
  },
  {
    id: 6,
    image: WillSmith,
    name: "Tom Cruise",
    title: "Founder & Chairman",
  },
];
