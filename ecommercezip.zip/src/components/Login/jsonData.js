export const userData = [
  {
    id: "100001",
    email: "helloworld@gmail.com",
    password: "helloworld001**",
    role: "user",
  },
  {
    id: "100002",
    email: "john@beatles.uk",
    password: "john12345**",
    role: "user",
  },
  {
    id: "100003",
    email: "admin@example.com",
    password: "admin12345**",
    role: "admin",
  },
];
