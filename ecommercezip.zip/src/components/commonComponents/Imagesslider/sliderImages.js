import Slider1 from "../../../assets/images/slider1.png";
import Slider2 from "../../../assets/images/slider2.png";
import Slider3 from "../../../assets/images/salesImage.png";
import Slider4 from "../../../assets/images/saleimage2.png";
import Slider5 from "../../../assets/images/imagesslider.jpg";
import Slider6 from "../../../assets/images/dogbanner.jpg";

export const SliderImages = [
  { id: 1, src: Slider1, alt: "Slider 1" },
  { id: 2, src: Slider2, alt: "Slider 2" },
  { id: 3, src: Slider3, alt: "Slider 3" },
  { id: 4, src: Slider4, alt: "Slider 4" },
  { id: 5, src: Slider5, alt: "Slider 5" },
  { id: 6, src: Slider6, alt: "Slider 6" },
];
