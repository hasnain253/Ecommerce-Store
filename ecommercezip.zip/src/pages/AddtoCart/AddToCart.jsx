import React from "react";
import ProductCart from "../../components/AddtoCart/ProductCart";

const AddToCart = () => {
  return (
    <div>
      <ProductCart />
    </div>
  );
};

export default AddToCart;
