import React from "react";
import Home from "../../components/Home/Home";

const ECommerceHome = () => {
  return (
    <div>
      <Home />
    </div>
  );
};

export default ECommerceHome;
