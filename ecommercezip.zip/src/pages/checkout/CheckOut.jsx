import React from "react";
import BillingCheckout from "../../components/BillingCheckout/BillingCheckout";

const CheckOut = () => {
  return (
    <div>
      <BillingCheckout />
    </div>
  );
};

export default CheckOut;
