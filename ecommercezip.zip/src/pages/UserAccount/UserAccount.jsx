import React from "react";
import Account from "../../components/userAccount/Account";

const UserAccount = () => {
  return (
    <div>
      <Account />
    </div>
  );
};

export default UserAccount;
